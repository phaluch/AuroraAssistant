import json
import boto3
import os
from datetime import datetime, date
from typing import Dict, Any, List, Optional
from todoist_api_python.api import TodoistAPI

# Initialize AWS clients
print("[DEBUG] Initializing boto3 client for Secrets Manager")
secrets_client = boto3.client("secretsmanager")
print("[DEBUG] Secrets Manager client initialized")

# Configuration
print("[DEBUG] Reading environment variable for SECRET_NAME")
SECRET_NAME = os.environ.get("TODOIST_SECRET_NAME")
print(f"[DEBUG] SECRET_NAME is set to: {SECRET_NAME}")


class TodoistJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder that handles datetime objects and removes null values."""

    def default(self, obj):
        print(f"[DEBUG] TodoistJSONEncoder.default called for object of type: {type(obj)}")
        if isinstance(obj, (datetime, date)):
            iso_format = obj.isoformat()
            print(f"[DEBUG]   Encoding datetime object to ISO format: {iso_format}")
            return iso_format
        print("[DEBUG]   Falling back to super().default")
        return super().default(obj)

    def encode(self, obj):
        print(f"[DEBUG] TodoistJSONEncoder.encode called for object: {obj}")

        # Remove null values recursively
        def remove_nulls(item):
            print(f"[DEBUG]   remove_nulls called for item: {item}")
            if isinstance(item, dict):
                print("[DEBUG]     Item is a dict, removing nulls from values.")
                return {k: remove_nulls(v) for k, v in item.items() if v is not None}
            elif isinstance(item, list):
                print("[DEBUG]     Item is a list, removing nulls from elements.")
                return [remove_nulls(v) for v in item if v is not None]
            else:
                print("[DEBUG]     Item is not a dict or list, returning as is.")
                return item

        print("[DEBUG] Cleaning object to remove null values.")
        cleaned_obj = remove_nulls(obj)
        print(f"[DEBUG] Object after cleaning null values: {cleaned_obj}")
        print("[DEBUG] Calling super().encode on the cleaned object.")
        return super().encode(cleaned_obj)


def get_api_token() -> str:
    """Retrieve Todoist API token from AWS Secrets Manager."""
    print("[DEBUG] ---> Entering get_api_token function")
    print(f"[DEBUG] Attempting to retrieve secret with SecretId: {SECRET_NAME}")
    try:
        response = secrets_client.get_secret_value(SecretId=SECRET_NAME)
        print("[DEBUG] Successfully called get_secret_value")
        print(f"[DEBUG] Raw response from Secrets Manager: {response}")
        secret = json.loads(response["SecretString"])
        print(f"[DEBUG] Parsed secret string: {secret}")
        token = secret.get("api_token", secret.get("token"))
        print(f"[DEBUG] Extracted token: {'*'*len(token) if token else 'None'}")
        print("[DEBUG] <--- Exiting get_api_token function successfully")
        return token
    except Exception as e:
        print(f"[DEBUG] ERROR: Failed to retrieve API token: {str(e)}")
        raise Exception(f"Failed to retrieve API token: {str(e)}")


def parse_labels(labels_str: Optional[str]) -> Optional[List[str]]:
    """Parse comma-separated labels string into a list."""
    print(f"[DEBUG] ---> Entering parse_labels with string: '{labels_str}'")
    if not labels_str:
        print("[DEBUG] Input string is empty or None. Returning None.")
        print("[DEBUG] <--- Exiting parse_labels")
        return None
    
    labels_list = [label.strip() for label in labels_str.split(",") if label.strip()]
    print(f"[DEBUG] Parsed list of labels: {labels_list}")
    print("[DEBUG] <--- Exiting parse_labels")
    return labels_list


def convert_to_dict(obj) -> Dict[str, Any]:
    """Convert API response object to dictionary, handling nested objects."""
    print(f"[DEBUG] ---> Entering convert_to_dict for object of type: {type(obj)}")
    if hasattr(obj, "to_dict"):
        print("[DEBUG]   Object has 'to_dict' method. Calling it.")
        result = obj.to_dict()
        print(f"[DEBUG]   Result from to_dict(): {result}")
        print("[DEBUG] <--- Exiting convert_to_dict")
        return result
    elif hasattr(obj, "__dict__"):
        print("[DEBUG]   Object has '__dict__' attribute. Converting manually.")
        result = {}
        for key, value in obj.__dict__.items():
            print(f"[DEBUG]     Processing key: '{key}' with value: {value}")
            if isinstance(value, list):
                print(f"[DEBUG]       Value for '{key}' is a list. Converting its items.")
                result[key] = [
                    convert_to_dict(item) if hasattr(item, "__dict__") else item
                    for item in value
                ]
            elif hasattr(value, "__dict__"):
                print(f"[DEBUG]       Value for '{key}' is a nested object. Converting it recursively.")
                result[key] = convert_to_dict(value)
            else:
                print(f"[DEBUG]       Value for '{key}' is a primitive. Assigning directly.")
                result[key] = value
        print(f"[DEBUG]   Manual conversion result: {result}")
        print("[DEBUG] <--- Exiting convert_to_dict")
        return result
    else:
        print("[DEBUG]   Object is not convertible. Returning as is.")
        print(f"[DEBUG] <--- Exiting convert_to_dict")
        return obj


# Task handlers
def handle_create_task(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle task creation."""
    print(f"[DEBUG] ---> Entering handle_create_task with params: {params}")
    content = params.get("content")
    if not content:
        print("[DEBUG] ERROR: Task content is missing.")
        raise ValueError("Task content is required for create operation")
    print(f"[DEBUG] Task content: '{content}'")

    task_params = {"content": content}
    print(f"[DEBUG] Initial task_params: {task_params}")

    # Add optional parameters
    if "description" in params:
        task_params["description"] = params["description"]
        print(f"[DEBUG] Added description to params: {task_params}")
    if "project_id" in params:
        task_params["project_id"] = params["project_id"]
        print(f"[DEBUG] Added project_id to params: {task_params}")
    if "priority" in params:
        try:
            priority = int(params["priority"])
            if 1 <= priority <= 4:
                task_params["priority"] = priority
                print(f"[DEBUG] Added valid priority to params: {task_params}")
        except ValueError:
            print(f"[DEBUG] Invalid priority value, skipping: {params['priority']}")
            pass
    if "due_string" in params:
        task_params["due_string"] = params["due_string"]
        print(f"[DEBUG] Added due_string to params: {task_params}")
    if "labels" in params:
        labels = parse_labels(params["labels"])
        if labels:
            task_params["labels"] = labels
            print(f"[DEBUG] Added labels to params: {task_params}")

    print(f"[DEBUG] Calling api.add_task with params: {task_params}")
    task = api.add_task(**task_params)
    print(f"[DEBUG] Received task object from API: {task}")
    
    task_dict = convert_to_dict(task)
    print(f"[DEBUG] Converted task object to dict: {task_dict}")

    response = {"message": f"Task '{task.content}' created successfully", **task_dict}
    print(f"[DEBUG] <--- Exiting handle_create_task with response: {response}")
    return response


def handle_update_task(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle task update."""
    print(f"[DEBUG] ---> Entering handle_update_task with params: {params}")
    task_id = params.get("task_id")
    if not task_id:
        print("[DEBUG] ERROR: Task ID is missing.")
        raise ValueError("Task ID is required for update operation")
    print(f"[DEBUG] Task ID for update: {task_id}")

    update_params = {}
    print("[DEBUG] Initial update_params: {}")
    if "content" in params:
        update_params["content"] = params["content"]
        print(f"[DEBUG] Added content to update_params: {update_params}")
    if "description" in params:
        update_params["description"] = params["description"]
        print(f"[DEBUG] Added description to update_params: {update_params}")
    if "priority" in params:
        try:
            update_params["priority"] = int(params["priority"])
            print(f"[DEBUG] Added priority to update_params: {update_params}")
        except ValueError:
            print(f"[DEBUG] Invalid priority value, skipping: {params['priority']}")
            pass
    if "due_string" in params:
        update_params["due_string"] = params["due_string"]
        print(f"[DEBUG] Added due_string to update_params: {update_params}")

    if not update_params:
        print("[DEBUG] ERROR: No update parameters were provided.")
        raise ValueError("No update parameters provided")

    print(f"[DEBUG] Calling api.update_task for task_id '{task_id}' with params: {update_params}")
    task = api.update_task(task_id, **update_params)
    print(f"[DEBUG] Received updated task object from API: {task}")

    task_dict = convert_to_dict(task)
    print(f"[DEBUG] Converted updated task to dict: {task_dict}")

    response = {"message": "Task updated successfully", **task_dict}
    print(f"[DEBUG] <--- Exiting handle_update_task with response: {response}")
    return response


def handle_complete_task(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle task completion."""
    print(f"[DEBUG] ---> Entering handle_complete_task with params: {params}")
    task_id = params.get("task_id")
    if not task_id:
        print("[DEBUG] ERROR: Task ID is missing.")
        raise ValueError("Task ID is required for complete operation")
    print(f"[DEBUG] Task ID to complete: {task_id}")

    print(f"[DEBUG] Calling api.complete_task for task_id '{task_id}'")
    result = api.complete_task(task_id)
    print(f"[DEBUG] API call result for complete_task: {result}")

    response = {
        "task_id": task_id,
        "message": "Task completed successfully",
        "success": result,
    }
    print(f"[DEBUG] <--- Exiting handle_complete_task with response: {response}")
    return response


def handle_get_task(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle getting a single task."""
    print(f"[DEBUG] ---> Entering handle_get_task with params: {params}")
    task_id = params.get("task_id")
    if not task_id:
        print("[DEBUG] ERROR: Task ID is missing.")
        raise ValueError("Task ID is required for get operation")
    print(f"[DEBUG] Task ID to get: {task_id}")
    
    print(f"[DEBUG] Calling api.get_task for task_id '{task_id}'")
    task = api.get_task(task_id)
    print(f"[DEBUG] Received task object from API: {task}")
    
    task_dict = convert_to_dict(task)
    print(f"[DEBUG] Converted task object to dict: {task_dict}")

    response = {"message": "Task retrieved successfully", **task_dict}
    print(f"[DEBUG] <--- Exiting handle_get_task with response: {response}")
    return response


def handle_list_tasks(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle listing tasks with filters."""
    print(f"[DEBUG] ---> Entering handle_list_tasks with params: {params}")
    list_params = {}
    print(f"[DEBUG] Initial list_params: {list_params}")

    if "project_id" in params:
        list_params["project_id"] = params["project_id"]
        print(f"[DEBUG] Added project_id to list_params: {list_params}")
    if "label" in params:
        list_params["label"] = params["label"]
        print(f"[DEBUG] Added label to list_params: {list_params}")

    tasks_data = []
    print("[DEBUG] Initialized empty tasks_data list")

    # Use filter if provided
    if "filter" in params:
        print(f"[DEBUG] Using filter to get tasks. Filter: '{params['filter']}'")
        tasks_iterator = api.filter_tasks(query=params["filter"])
    else:
        print(f"[DEBUG] Using get_tasks to list tasks with params: {list_params}")
        tasks_iterator = api.get_tasks(**list_params)

    print("[DEBUG] Iterating over the first page of results...")
    # Get first page of results
    for i, tasks_page in enumerate(tasks_iterator):
        print(f"[DEBUG] Processing page {i+1} of tasks.")
        for j, task in enumerate(tasks_page):
            print(f"[DEBUG]   Processing task {j+1} on page: {task.content}")
            task_dict = convert_to_dict(task)
            print(f"[DEBUG]   Converted task to dict: {task_dict}")
            tasks_data.append(task_dict)
        print("[DEBUG] Breaking after the first page.")
        break  # Only get first page

    response = {
        "tasks": tasks_data,
        "count": len(tasks_data),
        "message": f"Found {len(tasks_data)} tasks",
    }
    print(f"[DEBUG] <--- Exiting handle_list_tasks with response: {response}")
    return response


# Project handlers
def handle_create_project(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle project creation."""
    print(f"[DEBUG] ---> Entering handle_create_project with params: {params}")
    name = params.get("name")
    if not name:
        print("[DEBUG] ERROR: Project name is missing.")
        raise ValueError("Project name is required for create operation")
    print(f"[DEBUG] Project name: '{name}'")
    
    project_params = {"name": name}
    print(f"[DEBUG] Initial project_params: {project_params}")

    # Add optional parameters
    if "description" in params:
        project_params["description"] = params["description"]
        print(f"[DEBUG] Added description to project_params: {project_params}")
    if "parent_id" in params:
        project_params["parent_id"] = params["parent_id"]
        print(f"[DEBUG] Added parent_id to project_params: {project_params}")

    print(f"[DEBUG] Calling api.add_project with params: {project_params}")
    project = api.add_project(**project_params)
    print(f"[DEBUG] Received project object from API: {project}")

    project_dict = convert_to_dict(project)
    print(f"[DEBUG] Converted project object to dict: {project_dict}")

    response = {"message": f"Project '{project.name}' created successfully", **project_dict}
    print(f"[DEBUG] <--- Exiting handle_create_project with response: {response}")
    return response


def handle_update_project(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle project update."""
    print(f"[DEBUG] ---> Entering handle_update_project with params: {params}")
    project_id = params.get("project_id")
    if not project_id:
        print("[DEBUG] ERROR: Project ID is missing.")
        raise ValueError("Project ID is required for update operation")
    print(f"[DEBUG] Project ID for update: {project_id}")

    update_params = {}
    print(f"[DEBUG] Initial update_params: {update_params}")
    if "name" in params:
        update_params["name"] = params["name"]
        print(f"[DEBUG] Added name to update_params: {update_params}")
    if "description" in params:
        update_params["description"] = params["description"]
        print(f"[DEBUG] Added description to update_params: {update_params}")

    if not update_params:
        print("[DEBUG] ERROR: No update parameters provided.")
        raise ValueError("No update parameters provided")

    print(f"[DEBUG] Calling api.update_project for project_id '{project_id}' with params: {update_params}")
    project = api.update_project(project_id, **update_params)
    print(f"[DEBUG] Received updated project object from API: {project}")

    project_dict = convert_to_dict(project)
    print(f"[DEBUG] Converted updated project to dict: {project_dict}")

    response = {"message": "Project updated successfully", **project_dict}
    print(f"[DEBUG] <--- Exiting handle_update_project with response: {response}")
    return response


def handle_get_project(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle getting a single project."""
    print(f"[DEBUG] ---> Entering handle_get_project with params: {params}")
    project_id = params.get("project_id")
    if not project_id:
        print("[DEBUG] ERROR: Project ID is missing.")
        raise ValueError("Project ID is required for get operation")
    print(f"[DEBUG] Project ID to get: {project_id}")

    print(f"[DEBUG] Calling api.get_project for project_id '{project_id}'")
    project = api.get_project(project_id)
    print(f"[DEBUG] Received project object from API: {project}")

    project_dict = convert_to_dict(project)
    print(f"[DEBUG] Converted project object to dict: {project_dict}")

    response = {"message": "Project retrieved successfully", **project_dict}
    print(f"[DEBUG] <--- Exiting handle_get_project with response: {response}")
    return response


def handle_list_projects(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle listing projects."""
    print(f"[DEBUG] ---> Entering handle_list_projects with params: {params}")
    projects_data = []
    print("[DEBUG] Initialized empty projects_data list")

    print("[DEBUG] Calling api.get_projects() and iterating over the first page...")
    # Get first page of results
    for i, projects_page in enumerate(api.get_projects()):
        print(f"[DEBUG] Processing page {i+1} of projects.")
        for j, project in enumerate(projects_page):
            print(f"[DEBUG]   Processing project {j+1} on page: {project.name}")
            project_dict = convert_to_dict(project)
            print(f"[DEBUG]   Converted project to dict: {project_dict}")
            projects_data.append(project_dict)
        print("[DEBUG] Breaking after the first page.")
        break  # Only get first page

    response = {
        "projects": projects_data,
        "count": len(projects_data),
        "message": f"Found {len(projects_data)} projects",
    }
    print(f"[DEBUG] <--- Exiting handle_list_projects with response: {response}")
    return response


def handle_delete_project(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle project deletion."""
    print(f"[DEBUG] ---> Entering handle_delete_project with params: {params}")
    project_id = params.get("project_id")
    if not project_id:
        print("[DEBUG] ERROR: Project ID is missing.")
        raise ValueError("Project ID is required for delete operation")
    print(f"[DEBUG] Project ID to delete: {project_id}")

    print(f"[DEBUG] Calling api.delete_project for project_id '{project_id}'")
    result = api.delete_project(project_id)
    print(f"[DEBUG] API call result for delete_project: {result}")

    response = {
        "project_id": project_id,
        "message": "Project deleted successfully",
        "success": result,
    }
    print(f"[DEBUG] <--- Exiting handle_delete_project with response: {response}")
    return response


# Label handlers
def handle_create_label(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle label creation."""
    print(f"[DEBUG] ---> Entering handle_create_label with params: {params}")
    name = params.get("name")
    if not name:
        print("[DEBUG] ERROR: Label name is missing.")
        raise ValueError("Label name is required for create operation")
    print(f"[DEBUG] Label name: '{name}'")
    
    print(f"[DEBUG] Calling api.add_label with name: '{name}'")
    label = api.add_label(name=name)
    print(f"[DEBUG] Received label object from API: {label}")

    label_dict = convert_to_dict(label)
    print(f"[DEBUG] Converted label object to dict: {label_dict}")

    response = {"message": f"Label '{label.name}' created successfully", **label_dict}
    print(f"[DEBUG] <--- Exiting handle_create_label with response: {response}")
    return response


def handle_update_label(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle label update."""
    print(f"[DEBUG] ---> Entering handle_update_label with params: {params}")
    label_id = params.get("label_id")
    if not label_id:
        print("[DEBUG] ERROR: Label ID is missing.")
        raise ValueError("Label ID is required for update operation")
    print(f"[DEBUG] Label ID for update: {label_id}")

    update_params = {}
    if "name" in params:
        update_params["name"] = params["name"]
        print(f"[DEBUG] Added name to update_params: {update_params}")

    if not update_params:
        print("[DEBUG] ERROR: No update parameters provided.")
        raise ValueError("No update parameters provided")

    print(f"[DEBUG] Calling api.update_label for label_id '{label_id}' with params: {update_params}")
    label = api.update_label(label_id, **update_params)
    print(f"[DEBUG] Received updated label object from API: {label}")

    label_dict = convert_to_dict(label)
    print(f"[DEBUG] Converted updated label to dict: {label_dict}")

    response = {"message": "Label updated successfully", **label_dict}
    print(f"[DEBUG] <--- Exiting handle_update_label with response: {response}")
    return response


def handle_get_label(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle getting a single label."""
    print(f"[DEBUG] ---> Entering handle_get_label with params: {params}")
    label_id = params.get("label_id")
    if not label_id:
        print("[DEBUG] ERROR: Label ID is missing.")
        raise ValueError("Label ID is required for get operation")
    print(f"[DEBUG] Label ID to get: {label_id}")

    print(f"[DEBUG] Calling api.get_label for label_id '{label_id}'")
    label = api.get_label(label_id)
    print(f"[DEBUG] Received label object from API: {label}")
    
    label_dict = convert_to_dict(label)
    print(f"[DEBUG] Converted label object to dict: {label_dict}")

    response = {"message": "Label retrieved successfully", **label_dict}
    print(f"[DEBUG] <--- Exiting handle_get_label with response: {response}")
    return response


def handle_list_labels(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle listing labels."""
    print(f"[DEBUG] ---> Entering handle_list_labels with params: {params}")
    labels_data = []
    print("[DEBUG] Initialized empty labels_data list")

    print("[DEBUG] Calling api.get_labels() and iterating over the first page...")
    # Get first page of results
    for i, labels_page in enumerate(api.get_labels()):
        print(f"[DEBUG] Processing page {i+1} of labels.")
        for j, label in enumerate(labels_page):
            print(f"[DEBUG]   Processing label {j+1} on page: {label.name}")
            label_dict = convert_to_dict(label)
            print(f"[DEBUG]   Converted label to dict: {label_dict}")
            labels_data.append(label_dict)
        print("[DEBUG] Breaking after the first page.")
        break  # Only get first page

    response = {
        "labels": labels_data,
        "count": len(labels_data),
        "message": f"Found {len(labels_data)} labels",
    }
    print(f"[DEBUG] <--- Exiting handle_list_labels with response: {response}")
    return response

def handle_delete_label(api: TodoistAPI, params: Dict[str, str]) -> Dict[str, Any]:
    """Handle label deletion."""
    print(f"[DEBUG] ---> Entering handle_delete_label with params: {params}")
    label_id = params.get("label_id")
    if not label_id:
        print("[DEBUG] ERROR: Label ID is missing.")
        raise ValueError("Label ID is required for delete operation")
    print(f"[DEBUG] Label ID to delete: {label_id}")

    print(f"[DEBUG] Calling api.delete_label for label_id '{label_id}'")
    result = api.delete_label(label_id)
    print(f"[DEBUG] API call result for delete_label: {result}")

    response = {
        "label_id": label_id,
        "message": "Label deleted successfully",
        "success": result,
    }
    print(f"[DEBUG] <--- Exiting handle_delete_label with response: {response}")
    return response

# Snapshot handler
def handle_get_snapshot(api: TodoistAPI) -> Dict[str, Any]:
    """Handle retrieving a snapshot of all projects and their tasks/labels."""
    print("[DEBUG] ---> Entering handle_get_snapshot")
    print("[DEBUG] Starting snapshot retrieval...")
    
    # Correctly flatten paginated API responses into single lists
    try:
        print("[DEBUG] Attempting to get all projects with pagination flattening...")
        all_projects = [project for page in api.get_projects() for project in page]
        print(f"[DEBUG] Successfully retrieved {len(all_projects)} projects via pagination")
        
        print("[DEBUG] Attempting to get all labels with pagination flattening...")
        all_labels_list = [label for page in api.get_labels() for label in page]
        print(f"[DEBUG] Successfully retrieved {len(all_labels_list)} labels via pagination")
    except TypeError as e:
        print(f"[DEBUG] WARNING: Pagination failed with TypeError: {e}")
        print("[DEBUG] Falling back to direct API calls for projects and labels...")
        all_projects = api.get_projects()
        all_labels_list = api.get_labels()
        print(f"[DEBUG] Fallback successful - got {len(all_projects)} projects and {len(all_labels_list)} labels")
        
    print("[DEBUG] Creating labels dictionary for quick lookup...")
    all_labels = {label.id: label.name for label in all_labels_list}
    print(f"[DEBUG] Labels dictionary created with {len(all_labels)} entries: {all_labels}")
    
    snapshot_data = []
    print(f"[DEBUG] Processing {len(all_projects)} projects...")
    
    for i, project in enumerate(all_projects):
        print(f"[DEBUG] ===========================================================")
        print(f"[DEBUG] Processing project {i+1}/{len(all_projects)}: {project.name} (ID: {project.id})")
        project_tasks = []
        
        # Flatten the paginated task results for the current project
        try:
            print(f"[DEBUG]   Attempting to get all tasks for project {project.id} with pagination...")
            tasks_iterator = api.get_tasks(project_id=project.id)
            tasks_in_project = [task for page in tasks_iterator for task in page]
            print(f"[DEBUG]   Successfully retrieved {len(tasks_in_project)} tasks via pagination")
        except TypeError as e:
            print(f"[DEBUG]   WARNING: Task pagination failed with TypeError: {e}")
            print(f"[DEBUG]   Falling back to direct task API call for project {project.id}...")
            tasks_in_project = api.get_tasks(project_id=project.id)
            print(f"[DEBUG]   Fallback successful - got {len(tasks_in_project)} tasks")
            
        for j, task in enumerate(tasks_in_project):
            print(f"[DEBUG]   -------------------------------------------------")
            print(f"[DEBUG]   Processing task {j+1}/{len(tasks_in_project)}: {task.content} (ID: {task.id})")
            task_labels = []
            
            if task.label_ids:
                print(f"[DEBUG]     Task has {len(task.label_ids)} label IDs: {task.label_ids}")
                for label_id in task.label_ids:
                    if label_id in all_labels:
                        label_name = all_labels[label_id]
                        print(f"[DEBUG]       Adding label: {label_name} (ID: {label_id})")
                        task_labels.append(
                            {"label_id": label_id, "label_name": label_name}
                        )
                    else:
                        print(f"[DEBUG]       WARNING: Label ID {label_id} not found in labels dictionary")
            else:
                print("[DEBUG]     Task has no labels")
                
            task_data = {
                "task_id": task.id,
                "task_name": task.content,
                "labels": task_labels,
            }
            project_tasks.append(task_data)
            print(f"[DEBUG]     Task data added: {task_data}")
        
        project_data = {
            "project_id": project.id,
            "project_name": project.name,
            "tasks": project_tasks,
        }
        snapshot_data.append(project_data)
        print(f"[DEBUG]   Project '{project.name}' completed with {len(project_tasks)} tasks")
    
    print("[DEBUG] ===========================================================")
    print(f"[DEBUG] Snapshot creation completed successfully!")
    print(f"[DEBUG] Total projects processed: {len(snapshot_data)}")
    total_tasks = sum(len(project['tasks']) for project in snapshot_data)
    print(f"[DEBUG] Total tasks across all projects: {total_tasks}")
    
    response = {
        "projects": snapshot_data,
        "message": f"Snapshot retrieved successfully with {len(snapshot_data)} projects.",
    }
    print(f"[DEBUG] <--- Exiting handle_get_snapshot with response summary: {response['message']}")
    return response

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handle Bedrock Agent requests for Todoist operations.

    Routes to appropriate handler based on apiPath and operation parameter.
    """
    print("==================== LAMBDA INVOCATION START ====================")
    print(f"[DEBUG] Received event:\n{json.dumps(event, indent=2)}")
    print(f"[DEBUG] Received context: {context}")

    try:
        # Parse Bedrock event
        action_group = event.get("actionGroup", "")
        api_path = event.get("apiPath", "")
        http_method = event.get("httpMethod", "POST")
        print(f"[DEBUG] Parsed Event Details: actionGroup='{action_group}', apiPath='{api_path}', httpMethod='{http_method}'")

        # Extract parameters
        parameters = {
            param["name"]: param["value"] for param in event.get("parameters", [])
        }
        print(f"[DEBUG] Extracted Parameters: {parameters}")

        # Get operation type
        operation = parameters.get("operation")
        print(f"[DEBUG] Determined Operation: '{operation}'")
        if not operation:
            print("[DEBUG] ERROR: 'operation' parameter is missing from the request.")
            raise ValueError("Operation parameter is required")

        # Get API token and initialize client
        print("[DEBUG] Getting API token...")
        api_token = get_api_token()
        print("[DEBUG] API token retrieved. Initializing TodoistAPI client.")

        response_data = None
        # Route to appropriate handler based on apiPath and operation
        with TodoistAPI(api_token) as api:
            print("[DEBUG] TodoistAPI client context entered.")
            if api_path == "/tasks/manage":
                print("[DEBUG] Routing to task management.")
                if operation == "create":
                    response_data = handle_create_task(api, parameters)
                elif operation == "update":
                    response_data = handle_update_task(api, parameters)
                elif operation == "complete":
                    response_data = handle_complete_task(api, parameters)
                elif operation == "get":
                    response_data = handle_get_task(api, parameters)
                elif operation == "list":
                    response_data = handle_list_tasks(api, parameters)
                else:
                    raise ValueError(f"Unsupported task operation: {operation}")

            elif api_path == "/projects/manage":
                print("[DEBUG] Routing to project management.")
                if operation == "create":
                    response_data = handle_create_project(api, parameters)
                elif operation == "update":
                    response_data = handle_update_project(api, parameters)
                elif operation == "get":
                    response_data = handle_get_project(api, parameters)
                elif operation == "list":
                    response_data = handle_list_projects(api, parameters)
                elif operation == "delete":
                    response_data = handle_delete_project(api, parameters)
                else:
                    raise ValueError(f"Unsupported project operation: {operation}")

            elif api_path == "/labels/manage":
                print("[DEBUG] Routing to label management.")
                if operation == "create":
                    response_data = handle_create_label(api, parameters)
                elif operation == "update":
                    response_data = handle_update_label(api, parameters)
                elif operation == "get":
                    response_data = handle_get_label(api, parameters)
                elif operation == "list":
                    response_data = handle_list_labels(api, parameters)
                elif operation == "delete":
                    response_data = handle_delete_label(api, parameters)
                else:
                    raise ValueError(f"Unsupported label operation: {operation}")

            elif api_path == "/snapshot/manage":
                print("[DEBUG] Routing to snapshot management.")
                if operation == "get":
                    response_data = handle_get_snapshot(api)
                else:
                    raise ValueError(f"Unsupported snapshot operation: {operation}")

            else:
                raise ValueError(f"Unsupported API path: {api_path}")

        print(f"[DEBUG] Handler returned response_data: {response_data}")
        # Wrap response data
        final_response = {
            "success": True,
            "message": response_data.get(
                "message", f"Operation '{operation}' completed successfully"
            ),
            "data": response_data,
        }
        print(f"[DEBUG] Constructed final_response object: {final_response}")

        lambda_return_value = {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": action_group,
                "apiPath": api_path,
                "httpMethod": http_method,
                "httpStatusCode": 200,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps(final_response, cls=TodoistJSONEncoder)
                    }
                },
            },
        }
        print(f"[DEBUG] Final Lambda return value (SUCCESS):\n{json.dumps(lambda_return_value, indent=2)}")
        print("==================== LAMBDA INVOCATION END ====================")
        return lambda_return_value

    except ValueError as e:
        print(f"[DEBUG] ERROR CAUGHT (ValueError): {str(e)}")
        # Handle validation errors
        error_response = {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "apiPath": event.get("apiPath", ""),
                "httpMethod": event.get("httpMethod", "POST"),
                "httpStatusCode": 400,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps(
                            {
                                "success": False,
                                "error": "Bad Request",
                                "message": str(e),
                            },
                            cls=TodoistJSONEncoder,
                        )
                    }
                },
            },
        }
        print(f"[DEBUG] Final Lambda return value (BAD REQUEST):\n{json.dumps(error_response, indent=2)}")
        print("==================== LAMBDA INVOCATION END (ERROR) ====================")
        return error_response

    except Exception as e:
        # Handle all other errors
        print(f"[DEBUG] ERROR CAUGHT (Exception): {str(e)}")
        error_response = {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "apiPath": event.get("apiPath", ""),
                "httpMethod": event.get("httpMethod", "POST"),
                "httpStatusCode": 500,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps(
                            {
                                "success": False,
                                "error": "Internal Server Error",
                                "message": f"An unexpected error occurred: {str(e)}",
                            },
                            cls=TodoistJSONEncoder,
                        )
                    }
                },
            },
        }
        print(f"[DEBUG] Final Lambda return value (SERVER ERROR):\n{json.dumps(error_response, indent=2)}")
        print("==================== LAMBDA INVOCATION END (ERROR) ====================")
        return error_response